## 1. pip install decorator_libs

```
各种最常用的日常通用不针对具体业务的装饰器大全
```