## 1. pip install decorator_libs

```
各种最常用的日常通用不针对具体业务的装饰器大全

包括普通任意实现的装饰器
例如单例模式 享元模式 函数结果缓存装饰器。

和非常好玩但难实现的装饰器
例如where_is_it_called和pysnooper_click_able 装饰器。

上下文管理器：
自动捕获错误的
自动统计代码片段消耗时间的
redis分布式锁上下文
```

